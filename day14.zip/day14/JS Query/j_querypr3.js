$(document).ready(function(){
    $("#div1").draggable();
    
    $("#div2 span").draggable({
        containment:"div2"
    });
    $("#div3 span").draggable({
        axis:"x"
    });
    $("#div4 span").draggable({
        axis:"y"
    });
    $("#div5 span").draggable({
        distance:200
    });
    $("#div6 span").draggable({
        delay:3000
    });

});