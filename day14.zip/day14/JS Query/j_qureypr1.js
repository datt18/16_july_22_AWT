$(document).ready(function(){
    $("#tabdiv").tabs();
});