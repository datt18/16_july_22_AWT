$(document).ready(function(){
    $("#ageslider").slider({
        min:18,
        max:100,
        value:18,
        silde:function(event,ui){
            $("#age").val(ui,value);
        }
    });
    $("#age").val($("#ageslider").slider("value"));
    $("#price").slider({
        min:1,
        max:500,
        range:true,
        values:[1,50],
        start:function(event ,ui){
            $("#startvalue")
            .val("$"+ui.values[0]);

        },
        stop: function(event,ui){
            $("#endvalue")
            .val("$"+ui.values[1]);
        },
        change: function(event,ui){
            $("#changevalue")
            .val("$"+ui.values[0]+"-$"+ui.values[1]);

        },
        slide: function(event,ui){
            $("#slidervalue")
            .val("$"+ui.values[0]+"-$"+ui.values[1])
        }
    })
});